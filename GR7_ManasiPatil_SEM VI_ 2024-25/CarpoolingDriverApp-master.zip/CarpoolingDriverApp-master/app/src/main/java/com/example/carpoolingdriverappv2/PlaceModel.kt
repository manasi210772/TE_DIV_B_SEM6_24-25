package com.example.carpoolingdriverappv2

class PlaceModel(
    var id: Int,
    var drawableId: Int,
    var name: String,
    var placeType: String
)