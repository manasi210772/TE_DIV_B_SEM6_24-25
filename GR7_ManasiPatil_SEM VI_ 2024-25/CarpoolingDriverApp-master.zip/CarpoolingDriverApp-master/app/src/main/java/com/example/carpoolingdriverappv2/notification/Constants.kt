package com.example.carpoolingdriverappv2.notification

class Constants {
    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAACwkaHAM:APA91bFhENvvZDkR8I_cXJKBiVXR7M82BFOVoOxCxLACr4JDBq9wNdxyt16XB4EoyxOgGVdSr0AO6KuZJMpW52RsLWD-3Ao6EPtX1xVWP9qaSkkFPyS5w0u1QPOTSA0_QAP9fasrRXpU"
        const val CONTENT_TYPE = "application/json"
    }
}