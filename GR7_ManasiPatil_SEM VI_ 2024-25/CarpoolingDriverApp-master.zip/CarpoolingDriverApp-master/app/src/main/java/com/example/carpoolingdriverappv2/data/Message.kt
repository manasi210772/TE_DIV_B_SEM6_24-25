package com.example.carpoolingdriverappv2.data

data class Message(val message: String, val id: String, val time: String){
    
}