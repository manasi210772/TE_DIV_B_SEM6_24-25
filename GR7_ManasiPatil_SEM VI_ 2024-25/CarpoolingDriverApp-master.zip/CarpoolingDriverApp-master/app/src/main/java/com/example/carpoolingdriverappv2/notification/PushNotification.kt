package com.example.carpoolingdriverappv2.notification

data class PushNotification (
    val data: NotificationData,
    val to:String
)