package com.example.carpoolingdriverappv2.notification

data class NotificationData (
    val title: String,
    val message: String
)